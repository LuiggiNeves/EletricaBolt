<?php

namespace app\domain\service;

abstract class ServiceAbstract
{
    public function __construct()
    {
    }
}