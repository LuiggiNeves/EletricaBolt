<?php

# Dev env.
define("HOST_APP", "http://localhost/ELETRICABOLT");

define("DB_HOST", "127.0.0.1:3306");
define("DB_NAME", "bolt");
define("DB_USER", "root");
define("DB_PASSOWRD", "");

define("VERSION", "1");