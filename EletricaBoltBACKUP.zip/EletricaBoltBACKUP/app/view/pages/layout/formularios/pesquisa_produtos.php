<div class="row mb-3">
    <div class="col-sm-12 col-md-12">
        <label>Nome: </label>
        <input type="text" class="form-control form-control-sm w-100" id="pesquisarNomeProduto" />
    </div>
</div>

<div class="row mb-3">
    <div class="col-sm-12 col-md-3">
        <button class="btn btn-sm btn-primary w-100" id="btnPesquisarProdutos">Pesquisar</button>
    </div>
</div>